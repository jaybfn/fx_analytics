mt5_credentials = {'login': 7055689, 'server':'ICMarketsSC-MT5-2','password':'4KCEG3Kc'}
