
# path for logging
LOG_PATH = 'mt5_analysis.log'
# path to the data
FILE_PATH = 'fx_history.csv'

# Start_date
from datetime import datetime
DATETIME = datetime(2023, 9, 1) # year, month, day