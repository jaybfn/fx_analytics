
# path for logging
LOG_PATH = 'mt5_analysis.log'
# path to the data
FILE_PATH = 'fx_history.csv'