
mt5_credentials = {'login': '*****', 'server':'*****','password':'*****'}
